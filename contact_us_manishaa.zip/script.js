document.getElementById("contactForm").addEventListener("submit", function(event) {
  event.preventDefault(); // prevent actual submission

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const subject = document.getElementById("subject").value.trim();
  const message = document.getElementById("message").value.trim();
  const feedback = document.getElementById("feedback");

  // Basic Email Regex
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

  if (!name || !email || !subject || !message) {
    alert("All fields are required!");
    return;
  }

  if (!emailPattern.test(email)) {
    alert("Please enter a valid email address.");
    return;
  }

  // Success
  feedback.textContent = "Thank you! Your message has been submitted.";
  this.reset(); // clear the form
});
